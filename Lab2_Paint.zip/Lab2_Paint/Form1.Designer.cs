﻿
namespace Lab2_Paint
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Canvas = new System.Windows.Forms.PictureBox();
            this.FFImage = new System.Windows.Forms.PictureBox();
            this.FFImageName = new System.Windows.Forms.TextBox();
            this.BrouseButton = new System.Windows.Forms.Button();
            this.Work = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.ColorButton = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.Canvas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FFImage)).BeginInit();
            this.SuspendLayout();
            // 
            // Canvas
            // 
            this.Canvas.Location = new System.Drawing.Point(341, 10);
            this.Canvas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Canvas.Name = "Canvas";
            this.Canvas.Size = new System.Drawing.Size(511, 490);
            this.Canvas.TabIndex = 0;
            this.Canvas.TabStop = false;
            // 
            // FFImage
            // 
            this.FFImage.Location = new System.Drawing.Point(11, 256);
            this.FFImage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FFImage.Name = "FFImage";
            this.FFImage.Size = new System.Drawing.Size(311, 137);
            this.FFImage.TabIndex = 1;
            this.FFImage.TabStop = false;
            // 
            // FFImageName
            // 
            this.FFImageName.Location = new System.Drawing.Point(11, 398);
            this.FFImageName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FFImageName.Name = "FFImageName";
            this.FFImageName.Size = new System.Drawing.Size(312, 22);
            this.FFImageName.TabIndex = 2;
            // 
            // BrouseButton
            // 
            this.BrouseButton.Location = new System.Drawing.Point(11, 423);
            this.BrouseButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BrouseButton.Name = "BrouseButton";
            this.BrouseButton.Size = new System.Drawing.Size(311, 76);
            this.BrouseButton.TabIndex = 3;
            this.BrouseButton.Text = "Brouse";
            this.BrouseButton.UseVisualStyleBackColor = true;
            this.BrouseButton.Click += new System.EventHandler(this.BrouseButton_Click);
            // 
            // Work
            // 
            this.Work.FormattingEnabled = true;
            this.Work.Location = new System.Drawing.Point(167, 10);
            this.Work.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Work.Name = "Work";
            this.Work.Size = new System.Drawing.Size(155, 24);
            this.Work.TabIndex = 4;
            this.Work.SelectedIndexChanged += new System.EventHandler(this.Work_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "What to do";
            // 
            // ColorButton
            // 
            this.ColorButton.Location = new System.Drawing.Point(11, 192);
            this.ColorButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ColorButton.Name = "ColorButton";
            this.ColorButton.Size = new System.Drawing.Size(311, 59);
            this.ColorButton.TabIndex = 6;
            this.ColorButton.Text = "Choose Color";
            this.ColorButton.UseVisualStyleBackColor = true;
            this.ColorButton.Click += new System.EventHandler(this.ColorButton_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(184, 85);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(110, 21);
            this.radioButton1.TabIndex = 7;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(184, 113);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(110, 21);
            this.radioButton2.TabIndex = 8;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 509);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.ColorButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Work);
            this.Controls.Add(this.BrouseButton);
            this.Controls.Add(this.FFImageName);
            this.Controls.Add(this.FFImage);
            this.Controls.Add(this.Canvas);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Canvas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FFImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Canvas;
        private System.Windows.Forms.PictureBox FFImage;
        private System.Windows.Forms.TextBox FFImageName;
        private System.Windows.Forms.Button BrouseButton;
        private System.Windows.Forms.ComboBox Work;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button ColorButton;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}

